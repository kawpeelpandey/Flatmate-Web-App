document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const fname = document.getElementById('fname').value;
    const lname = document.getElementById('lname').value;
    const phone = document.getElementById('phone').value;
    const age = document.getElementById('age').value;
    const email = document.getElementById('email').value;
    const message = document.getElementById('message').value;

    const namePattern = /^[a-zA-Z\s]+$/;
    const phonePattern = /^\d{10,15}$/; // Allow phone numbers between 10 to 15 digits
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

    if (!namePattern.test(fname) || !namePattern.test(lname)) {
        alert('Please enter a valid name.');
        return;
    }

    if (phone && !phonePattern.test(phone)) {
        alert('Please enter a valid phone number (10 to 15 digits).');
        return;
    }

    if (age && (isNaN(age) || age < 18 || age > 99)) {
        alert('Please enter a valid age (18-99).');
        return;
    }

    if (!emailPattern.test(email)) {
        alert('Please enter a valid email address.');
        return;
    }

    const formData = { fname, lname, phone, age, email, message };
    sessionStorage.setItem('contactFormData', JSON.stringify(formData));

    window.location.href = 'thank-you.html';
});
