document.addEventListener('DOMContentLoaded', function() {
    const formData = JSON.parse(sessionStorage.getItem('contactFormData'));
    if (formData) {
        const { fname, lname, phone, age, email, message } = formData;
        document.getElementById('thank-you-details').innerHTML = `
            <p>Thank you, ${fname} ${lname}!</p>
            <p>We have received your information:</p>
            <ul>
                <li><strong>Phone:</strong> ${phone}</li>
                <li><strong>Age:</strong> ${age}</li>
                <li><strong>Email:</strong> ${email}</li>
                <li><strong>Message:</strong> ${message}</li>
            </ul>
        `;
    }
});
